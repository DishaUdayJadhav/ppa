package com.marvellous.MarvellousPortal.service;

import com.marvellous.MarvellousPortal.Entity.BatchEntry;
import com.marvellous.MarvellousPortal.Repositary.BatchEntryRepositary;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class BatchEntryService
{
    @Autowired
    private BatchEntryRepositary batchEntryRepositary;

    //C:Create
    //POST
    public void SaveEntry(BatchEntry batchEntry)
    {
        batchEntryRepositary.save(batchEntry);
    }

    //R:Read
    //GET

    public List<BatchEntry> getAll()
    {
        return batchEntryRepositary.findAll();
    }

    //R :Read
    //GET
    public Optional <BatchEntry> findById(ObjectId id)
    {
        return batchEntryRepositary.findById(id);
    }

    //D:Delete
    //DELETE
    public void deleteById(ObjectId id)
    {
        batchEntryRepositary.deleteById(id);
    }

    public void updateEntry(BatchEntry batchEntry) {
        batchEntryRepositary.save(batchEntry);
    }

}
